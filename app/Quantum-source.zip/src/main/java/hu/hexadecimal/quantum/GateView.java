package hu.hexadecimal.quantum;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.widget.TextView;



public class GateView extends TextView {

    private String gate;

    GateView(Context con) {
        super(con);
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {}});
    }

    @Override
    public void setOnClickListener(View.OnClickListener l) {
        super.setOnClickListener(l);
        AlertDialog.Builder gates = new AlertDialog.Builder(super.getContext());
        gates.setIcon(android.R.drawable.ic_dialog_map);
        gates.setTitle("Choose a gate");
        //gates.setSingleChoiceItems()
    }
}
