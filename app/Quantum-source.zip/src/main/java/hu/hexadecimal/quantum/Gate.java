package hu.hexadecimal.quantum;

import java.util.List;

public class Gate {

    private static final String HADAMARD = "Hadamard";
    private static final String PAULI_X = "Pauli-X";
    private static final String PAULI_Y = "Pauli-Y";
    private static final String PAULI_Z = "Pauli-Z";
    public static final String[] gateNames = {HADAMARD, PAULI_X, PAULI_Y, PAULI_Z};

}
