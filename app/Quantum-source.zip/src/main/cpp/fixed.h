//
// Created by cseha on 2018.08.24..
//

#ifndef QUANTUM_FIXED_H
#define QUANTUM_FIXED_H


class fixed {
private:
    char value[];
public:

};


#endif //QUANTUM_FIXED_H
